function [PC, k, k_th, D, Dnew, sigma2_hat, M1hat] = AugSPCA(X, L,...
    basis, par, alpha, beta, dothres, num_eig, sigma2)

% AugSPCA --- Augmented Sparse PCA 
% (Code adapted from Debashis Paul's original version)

% INPUT
%     X           n-by-p data matrix
%     L           coarsest level in wavelet transform
%     basis       wavelet basis to be used, choose one from 'Haar', 'Beylkin', 
%                 'Coiflet', 'Daubechies', 'Symmlet', 'Vaidyanathan','Battle'
%     par         parameter describing the support length and vanishing
%                 moments of the selected wavelet basis
%     alpha       adjustable constant in the diagonal thresholding step
%     beta        adjustable constant in the iterative thresholding steps
%     dothres     thesholding rule used in the final step, 'hard' is
%                 recommended
%     num_eig     number of eigenvectors to be computed
%     sigma2      prescribed noise varaince level
%     
% OUTPUT
%     PC          p-by-(num_eig) matrix, columns corresponding to leading
%                 eigenvectors
%     k           a vector recording support sizes for the PC's in the
%                 transform domain
%     k_th        support size after the final thresholding step
%     D           estimated leading eigenvalues based on the initial
%                 coordinates
%     Dnew        estimated leading eigenvalues based on the augmented
%                 coordinates
%     sigma2_hat  estimated noise variance level 
%                 (the same as sigma2 if the later is supplied by the user)
%     M1hat       estimated number of spikes

[n,p] = size(X);
if nargin == 7
  num_eig = 1;
end

% DWT of the data: "wc" contains the coefficients
wc = zeros(n,p);
if strcmp(basis,'delta') == 1
    wc = X;
else
    qmf  = MakeONFilter(basis, par);
    for i = 1:n
        wc(i, :) = FWT_PO(X(i, :), L, qmf);
    end
end

wc_mean = mean(wc);
wc_dm = wc - ones(n,1)*wc_mean;         % de-meaned obs

% Compute Johnstone & Lu's DT estimator as the initial value
wc_var = var(wc);
if nargin < 9
%     sigma2_hat = median(wc_var(p/2:p)); 
%     % different from JL's original proposal, only valid when using
%     % a multi-resolution basis
    sigma2_hat = median(wc_var);
else
    sigma2_hat = sigma2;
end

pn = max(p,n);
th = sqrt(log(pn)/2);
I_signal = find( wc_var / sigma2_hat  > 1 + alpha * sqrt(2/n) * th ); ...
% Debashis' original code suggest using alpha = 3
if numel(I_signal) <= num_eig
    [~, idx] = sort(wc_var,'descend');
    I_signal = idx(1:min(num_eig+10,p));
end

I_sig_up = find( wc_var / sigma2_hat  > 1 + (sqrt(11)/9) * alpha * ...
                 sqrt(2/n) * th );       % called indexnewup in DP's
                                        % code

[Uspc1, Dspc1, ~] = svd(cov(wc(:,I_signal)), 0);

thr1 = sigma2_hat*(1+2*(sqrt(log(pn))+pi)*sqrt(length(I_sig_up)/n));
M1hat = sum(diag(Dspc1 > thr1));        % estimated # significant
                                        % e-val's
                                        
if M1hat < num_eig
    disp('AugSPCA: # spikes underestimated. Corrected to specified number!');
    M1hat = num_eig;
end

% Augmentation of the selected coordinate set
Ev = Uspc1(:,1:M1hat);

I_off = setdiff(1:p, I_signal);
Cov_off = wc_dm(:, I_off)'* wc_dm(:, I_signal)/n;

D = Dspc1(1:M1hat, 1:M1hat);

Ev_raw = Cov_off * Ev / sqrt(D);
size_raw = diag(Ev_raw * Ev_raw');

delta_n = log(pn * sqrt(Dspc1(1,1)/sigma2_hat)) / n;
% asymptotically optimal threshold

thr2 = beta * sigma2_hat * delta_n * ...
       (1 + 1/sqrt(2) * sqrt( M1hat / delta_n / n ))^2;
% It is suggested by DP that beta = 2

I_sur = size_raw > sigma2_hat * thr2;
I_aug = I_off(I_sur);
I_sig_auged = union(I_signal, I_aug);

k = length(I_sig_auged);

[Unew Dnew ~] = svd(cov(wc(:,I_sig_auged)), 0);
Dnew = Dnew(1:M1hat, 1:M1hat);


% hard thresholding the augmented estimator
if strcmp(dothres, 'hard') == 1
    hlambda = (diag(Dnew(1:M1hat,1:M1hat)-sigma2_hat).^2)./(diag(Dnew)); 
    tau = sqrt(sigma2_hat)*sqrt(2)*sqrt(log(pn))./sqrt(n*hlambda);
else
    tau = zeros(1, num_eig);
end

PC = zeros(p, num_eig);
k_th = zeros(1, num_eig);
pc_raw = zeros(p, 1);

for i = 1:num_eig
  temp = hard_thresholding(Unew(:,i), tau(i))';
  k_th(1,i) = length(find(temp));
  pc_raw(I_sig_auged,1) = temp;
  PC(:,i) = IWT_PO(pc_raw, L, qmf);
end

