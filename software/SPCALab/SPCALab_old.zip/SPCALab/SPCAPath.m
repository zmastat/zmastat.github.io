disp('Welcome to SPCALab V0.1!');
disp(' ');
disp('Setting up paths...');

WAVELABPATH = fullfile(matlabroot,'toolbox','Wavelab850')

% adapted from WavePath.m in Wavelab850
while (exist(WAVELABPATH)~=7)
    WAVELABPATH = input(sprintf('Directory %s does not exist.\nEnter the correct path (type 0 to exit): ',WAVELABPATH),'s')
    if WAVELABPATH == '0'
        fprintf('\nErrors occurs and Wavelab paths have not been set up!\n')
        fprintf('\nPlease Identify the correct Wavelab directory!\n\n')
        clear all;
        return;
    end
    WAVELABPATH = fullfile(WAVELABPATH);
end

fprintf('\nWavelab directory identified.\n');
fprintf('\nIncluding required WaveLab paths:\n');
path(fullfile(WAVELABPATH, 'Orthogonal'), path);
path(fullfile(WAVELABPATH, 'Utilities'), path);
fprintf('Required Wavelab paths are set up.\n');

fprintf('\nIncluding required splines toolbox paths:\n');
if (exist(fullfile(matlabroot,'toolbox','splines'))~=7)
    disp('Warning: Standard splines toolbox not available! SmoothPCA.m will not run!');
end
path(fullfile(matlabroot,'toolbox','splines'), path);
fprintf('Required splines toolbox paths are set up.\n');

SPCAPATH = cd
fprintf('\nIncluding SPCALab paths:\n');
addpath(genpath(SPCAPATH));

% path(fullfile(ASPCAPATH,'AdaptivePCA'), path);
% path(fullfile(ASPCAPATH,'Documentation'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09Discussion'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09Rejoinder'), path);
% path(fullfile(ASPCAPATH,'SmoothedPCA'), path);
% path(fullfile(ASPCAPATH,'Utilities'), path);

fprintf('SPCALab paths are set up.\n');

MODSTARTUP = ' ';
while (MODSTARTUP ~= 'y' & MODSTARTUP ~= 'n')
    MODSTARTUP = input(sprintf('Do you want to add SPCALab paths to your startup.m?\n[y for Yes/n for NO]\n'),'s');
    if isempty(MODSTARTUP)
        MODSTARTUP = 'y';
    end
end
if MODSTARTUP == 'y'
    disp('Modifying startup.m:');
    STARTUPPATH = userpath;
    STARTUPPATH = STARTUPPATH(1:end-1);
    fid = fopen(fullfile(STARTUPPATH, 'startup.m'),'a+');
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'AdaptivePCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'ITSPCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'AugSPCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'CORRPCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Documentation'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Paper','JASA09'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Paper','JASA09','Discussion'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Paper','JASA09','Rejoinder'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Paper','SPCAIT11'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'SmoothedPCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(SPCAPATH,'Utilities'));
    fclose(fid);
    disp('Modification to startup.m is completed.');
    fprintf('\nSPCALab V0.1 is successfully installed!\n\n');
else
    fprintf('\nSPCALab V0.1 is ready for use in the current MATLAB session!\n\n')
end

% last modified: ZM, 2011-07-30


