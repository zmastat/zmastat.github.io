% Figure 2 of Ma (2011):
% Discrete wavlet transform (Symmlet 8) of the four test vectors in Fig.1.

fprintf('This function reproduces Fig.2 of Ma (2011).\n\n');

% WavePath;
basis = 'Symmlet';
par   = 8;
L = 3;

qmf  = MakeONFilter(basis, par);

rhoPeak_wc = FWT_PO(rhoPeak, L, qmf);
rhoPoly_wc = FWT_PO(rhoPoly, L, qmf);
rhoStep_wc = FWT_PO(rhoStepNew, L, qmf);
rhoSing_wc = FWT_PO(rhoSing, L, qmf);

h = figure('Position', [0 0 1200 600]); 

subplot(223); 
PlotWaveCoeff(rhoPeak_wc, L, 0);
box on;
title('(c) DWT of 3-peak function (Symmlet 8).', 'FontSize', 11);
xlabel('Location'); ylabel('Resolution level');

subplot(221); 
PlotWaveCoeff(rhoStep_wc, L, 0);
box on;
title('(a) DWT of step function (Symmlet 8).', 'FontSize', 11);
xlabel('Location'); ylabel('Resolution level');

subplot(222);
PlotWaveCoeff(rhoPoly_wc, L, 0);
box on;
title('(b) DWT of piecewise polynomial function (Symmlet 8).', 'FontSize', 11);
xlabel('Location'); ylabel('Resolution level');

subplot(224); 
PlotWaveCoeff(rhoSing_wc, L, 0);
box on;
title('(d) DWT of single singularity function (Symmlet 8).', 'FontSize', 11);
xlabel('Location'); ylabel('Resolution level');

% set(gcf,'PaperPositionMode','auto');
% 
% print(h, '-depsc', 'testsigwave.eps'); 
% 
% close all;
