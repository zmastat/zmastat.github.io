% Table 1 of Ma (2011):
% Comparison of sparse PCA methods in single spike settings: average loss
% in estimation and size of selected feature set.

disp('This function reproduces Table 1 of Ma (2011).');
R = input('Have you run the single spike simulation? [Yes/No]\n', 's');
if strcmp(R,'') || strcmp(R,'Yes') || strcmp(R,'yes') || strcmp(R,'y') || strcmp(R,'Y') || strcmp(R,'YES')

    lambda2 = [100, 25, 10, 5, 2]';
    nlambda = size(lambda2);
    nlambda = nlambda(1);
    
    signals = ['Step' 'Poly' 'Peak' 'Sing'];
    
    result = zeros(100, 160);
    
    for j = 1:4
        
        signal = signals((j-1)*4+(1:4));
        
        for i = 1:nlambda
            file = strcat(cd, '/single/', signal, '_lambda2_', num2str(lambda2(i)), ...
                '_1normal_0_niter100_Symmlet8_itspca_hard150.csv');
            exprcd = csvread(file);
            result(:,40*(j-1)+8*(i-1)+(1:2)) = exprcd(:,[4 2]);
            
            file = strcat(cd, '/single/', signal, '_lambda2_', num2str(lambda2(i)), ...
                '_1normal_0_niter100_Symmlet8_augpca_hard200.csv');
            exprcd = csvread(file);
            result(:,40*(j-1)+8*(i-1)+(3:4)) = exprcd(:,[4 2]);
            
            file = strcat(cd, '/single/', signal, '_lambda2_', num2str(lambda2(i)), ...
                '_1normal_0_niter100_Symmlet8_corpca_none002.csv');
            exprcd = csvread(file);
            result(:,40*(j-1)+8*(i-1)+(5:6)) = exprcd(:,[4 2]);
            
            file = strcat(cd, '/single/', signal, '_lambda2_', num2str(lambda2(i)), ...
                '_1normal_0_niter100_Symmlet8_jlspca_hard100.csv');
            exprcd = csvread(file);
            result(:,40*(j-1)+8*(i-1)+(7:8)) = exprcd(:,[4 2]);
        end
        
    end
    
    avg = mean(result);
    avg_table = zeros(20,9);
    avg_table(:,1) = repmat(lambda2, 4, 1);
    for j = 1:4
        for i = 1:5
            avg((j-1)*40+(i-1)*8+(1:8));
            avg_table((j-1)*5+i,2:end) = avg((j-1)*40+(i-1)*8+(1:8));
        end
    end
    
    disp(' ');
    disp('                              ===== Table 1 of Ma (2011) ===== ');
    disp(' ');
    disp('                    ITSPCA              AUGSPCA             CORSPCA             DTSPCA')
    disp('  lambda^2      Loss      Size      Loss      Size      Loss      Size      Loss      Size');
    disp('Step:');
    disp(avg_table(1:5,:));
    disp('Poly:');
    disp(avg_table(6:10,:));
    disp('Peak:');
    disp(avg_table(11:15,:));
    disp('Sing:');
    disp(avg_table(16:20,:));
    
%     latex(avg_table, '%i', '%.4f', '%.1f', '%.4f', '%.1f', '%.4f', '%.1f', '%.4f', '%.1f');

else
    disp('Table 1 could not be reproduced! Run simu_single.m first!');
end