% Figure 1 of Ma (2011):
% Four test vectors in the original domain.

fprintf('This function reproduces Fig.1 of Ma (2011).\n\n');


% set(gcf,'PaperPositionMode','auto');

load rhoPeak;
load rhoPiecePoly;
load rhoStepNew;
load rhoSing;

rhoPoly = rhoPiecePoly/norm(rhoPiecePoly);
rhoPeak = rhoPeak/norm(rhoPeak);
rhoStepNew = rhoStepNew/norm(rhoStepNew);
rhoSing = rhoSing/norm(rhoSing);

% Plot test signals in the original domain

% close all;
h = figure('Position', [0 0 1200 600]); 

p = size(rhoStepNew, 1);
x = linspace(1/p,1,p);

subplot(221); 
plot(x, rhoStepNew);
box on;
title('(a) Step function', 'FontSize', 11);
xlabel('Location'); 

subplot(222); 
plot(x, rhoPoly);
box on;
title('(b) Piecewise polynomial function', 'FontSize', 11);
xlabel('Location'); 

subplot(223); 
plot(x, rhoPeak);
box on;
title('(c) Three peak function', 'FontSize', 11);
xlabel('Location'); 

subplot(224); 
plot(x, rhoSing);
box on;
title('(d) Single singularity function', 'FontSize', 11);
xlabel('Location'); 

% set(gcf,'PaperPositionMode','auto');
% 
% print(h, '-depsc', 'testsigorig.eps'); 
% close all;

