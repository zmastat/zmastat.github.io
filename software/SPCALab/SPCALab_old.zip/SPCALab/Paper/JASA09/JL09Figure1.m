% Figure 1 of Johnstone and Lu (2009):
% 3-peak function and PCs from standard, smoothed, and ASPCA.

fprintf('This function reproduces Fig.1 of Johnstone & Lu (2009).\n');
fprintf('Processing...\n\n');

% set seed
state = 100;
randn('state', state);

% set parameter
n = 1024;
p = 2048;
% noise level sigma = 1
sigma = 1;
len = 10;
perc = 0.995;
% use the symmlet basis as the wavelet basis
basis = 'Symmlet';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%  Construct 3-Peak Function  %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ps = linspace(0,1,p);
rhoPeak = 0.7 * betapdf(ps,1500,3000)...
        + 0.5 * betapdf(ps,1200,900)...
        + 0.5 * betapdf(ps,600,160);
rhoPeak = len * rhoPeak' / norm(rhoPeak);

% Generate data matrix (1024 * 2048) Xpeak 
% each row of Xpeak corresponds to an observation of the rhoPeak function
% with noise
mu = 0 * (1:p);
Xpeak  = GenData(n, mu, rhoPeak', sigma);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%  Different PCAs on 3-Peak Function  %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for determining the sign of the eigenvector
idx = find(rhoPeak == max(rhoPeak));

%%%%%%%%%%%%%%%%
% Standard PCA %
%%%%%%%%%%%%%%%%
[V,D] = eig(cov(Xpeak));
V = V(:,p); V = sign(V(idx,1)) * V;
rhoPeakHat_st = len * V / norm(V');

dif_st = rhoPeak - rhoPeakHat_st;
fprintf('The MSE of standard PCA is:\n');
disp(num2str(norm(dif_st) / p));

%%%%%%%%%%%%%%%%
% Smoothed PCA %
%%%%%%%%%%%%%%%%

% lambda = 10E-12
SmPC = SmoothPCA(Xpeak, ps, 10^(-12));
SmPC = SmPC(:,1); SmPC = sign(SmPC(idx,1)) * SmPC;
rhoPeakHat_12 = len * SmPC/norm(SmPC');

dif_12 = rhoPeak - rhoPeakHat_12;
fprintf('The MSE of smoothed PCA with smoothness penalty 10E-12 is:\n');
disp(num2str(norm(dif_12) / p));

% lambda = 10E-6
SmPC = SmoothPCA(Xpeak, ps, 10^(-6));
SmPC = SmPC(:,1); SmPC = sign(SmPC(idx,1)) * SmPC;
rhoPeakHat_6 = len * SmPC/norm(SmPC');

dif_6 = rhoPeak - rhoPeakHat_6;
fprintf('The MSE of smoothed PCA with smoothness penalty 10E-6 is:\n');
disp(num2str(norm(dif_6) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adaptive Sparse PCA W/O thresholding %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[AsPC, card_sub, th] = ASPCA(Xpeak, 8, basis, perc, 'none');
AsPC = sign(AsPC(idx,1)) * AsPC;
rhoPeakHat_nt = len * AsPC/norm(AsPC');

dif_nt = rhoPeak - rhoPeakHat_nt;
fprintf('The MSE of Adaptive SPCA without thresholding is:\n');
disp(num2str(norm(dif_nt) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adaptive Sparse PCA with hard thresholding, th = 0.01 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[AsPC, card_sub1, th] = ASPCA(Xpeak, 8, basis, perc, 'hard');
AsPC = sign(AsPC(idx,1)) * AsPC;
rhoPeakHat_t = len * AsPC/norm(AsPC');

dif_t = rhoPeak - rhoPeakHat_t;
fprintf('The MSE of Adaptive SPCA with hard thresholding at 0.01 is:\n');
disp(num2str(norm(dif_t) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%            Plot 6 graphs           %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clf;
subplot(2,3,1);
plot(rhoPeak, 'black');
box on;
axis([0 2048 -0.2 1.7]);
title('a) True PC, p = 2048, n = 1024, ||\rho|| = 10.');

subplot(2,3,2)
plot(1:2048, Xpeak(1,:))
axis([0 2048 -4 4]);
title('b) A sample path from model (2)')

subplot(2,3,3);
hold on;
box on;
l2 = plot(rhoPeakHat_st,'blue');
axis([0 2048 -0.2 1.7]);
title('c) Standard PCA');

subplot(2,3,4);
axis([0 2048 -0.2 1.7]);
hold on;
box on;
l2 = plot(rhoPeakHat_12,'red -');
l3 = plot(rhoPeakHat_6,'blue --');
legend([l2 l3], '\lambda=10^{-12}', '\lambda=10^{-6}');
title('d) Smoothed PCA');

subplot(2,3,5);
hold on;
box on;
axis([0 2048 -0.2 1.7]);
l2 = plot(rhoPeakHat_nt,'blue');
tit = strcat('e) ASPCA: w=', num2str(perc), ', k=', int2str(card_sub), '. ');
title(strcat(tit, ' No thres.'));

subplot(2,3,6);
hold on;
box on;
axis([0 2048 -0.2 1.7]);
l2 = plot(rhoPeakHat_t,'blue');
tit = strcat('f) ASPCA: w=', num2str(perc), ', k=', int2str(card_sub1), '. ');
title(strcat(tit, ' Thres=', num2str(th,3), '.'));
