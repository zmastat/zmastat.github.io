load rhoPeak;
load rhoStep;

basis = 'Symmlet';
L = 8;
p = 2048;
n = 1024;   
sigma2 = 1;
qmf = MakeONFilter(basis,8);
wcPeak = FWT_PO( rhoPeak, L, qmf)';

wc2 = sort(wcPeak.^2);
tbias2 = reverse(cumsum(wc2));
tbias2 = [tbias2(2:end) 0];
kvec = 1:p;
projrisk = (kvec - 1)./n;
%noise = ones(1,p)./n;
r2 = reverse(wc2);
% ideal = cumsum(min(r2,noise));
% threshrisk = (1+2.*log(kvec)) .*(noise + ideal);
%threshrisk = ideal;

lamvec = sqrt(2.*log(kvec));
absrho = sqrt(r2);
nois = sqrt(1./n);
betterrisk = zeros(1,p);

for k=1:p
    rho = absrho(1:k);
    risk = riskbound(rho,lamvec(k),nois);
    betterrisk(k) = sum(risk);
end

asePeakproj = sqrt(tbias2 + projrisk) ./p;
%asePeakthr  = sqrt(tbias2 + threshrisk) ./p;
asePeakbet  = sqrt(tbias2 + betterrisk) ./p;


basis = 'Haar';
qmf = MakeONFilter(basis,8);
wcStep = FWT_PO( rhoStep, L, qmf)';

wc2 = sort(wcStep.^2);
tbias2 = reverse(cumsum(wc2));
tbias2 = [tbias2(2:end) 0];
kvec = 1:p;
projrisk = (kvec - 1)./n;
noise = ones(1,p)./n;
r2 = reverse(wc2);
% ideal = cumsum(min(r2,noise));
% threshrisk = (1+2.*log(kvec)) .*(noise + ideal);
%threshrisk = ideal;

lamvec = sqrt(2.*log(kvec));
absrho = sqrt(r2);
nois = sqrt(1./n);
betterrisk = zeros(1,p);

for k=1:p
    rho = absrho(1:k);
    risk = riskbound(rho,lamvec(k),nois);
    betterrisk(k) = sum(risk);
end

aseStepproj = sqrt(tbias2 + projrisk) ./p;
% aseStepthr  = sqrt(tbias2 + threshrisk) ./p;
aseStepbet  = sqrt(tbias2 + betterrisk) ./p;

clf;
plot( 1:p, log10(asePeakproj));
hold on;
% plot( 1:p, log10(asePeakthr), 'g');
axis([0 2048 -4.5 -1.5]);
plot( 1:p, log10(aseStepproj),'ro');
legend('PEAK','STEP');


hold on;
% plot( 1:p, log10(aseStepthr), 'go');
plot( 1:p, log10(asePeakbet));
plot( 1:p, log10(aseStepbet), 'ro');
xlabel('number of features k');
ylabel(texlabel('log_{10}(ASE)'));
print -dpdf discfig1;
