% Figure 3 of Johnstone and Lu (2009):
% Simulation study: accuracy comparison of standard, smoothed, and adaptive
% sparse PCA. Also record simulation results which leads to Table 1.


disp('This function reproduces Fig.3 of Johnstone & Lu (2009).');
disp('It will take several hours to complete the simulation,');
disp('which is also necessary for producing Table 1 using JL09Table1.m.')
R = input('Do you want to run it now? [Yes/No]\n', 's');
if strcmp(R,'') || strcmp(R,'Yes') || strcmp(R,'yes') || strcmp(R,'y') || strcmp(R,'Y') || strcmp(R,'YES')
    fprintf('Processing...\n\n');
    state = 100; 
    randn('state', state);

    niter = 50;
    n = 1024;
    p = 2048;
    ps = linspace(0,1,p);
    sigma = 1;
    perc = .995;
    load -ascii rhoPeak;
    load -ascii rhoStep;
    len_peak = norm(rhoPeak);
    len_step = norm(rhoStep);
    idx_peak = find(rhoPeak == max(rhoPeak)); idx_peak = idx_peak(1);
    idx_step = find(rhoStep == max(rhoStep)); idx_step = idx_step(1);
    mu_peak = zeros(1,p);
    mu_step = zeros(1,p);

    time_peak = zeros(niter, 5);
    time_step = time_peak;
    ase_peak = time_peak;
    ase_step = ase_peak;

    for i = 1:niter
        %%%%%%%%%%%%%%%%%
        % peak function %
        %%%%%%%%%%%%%%%%%
        Xpeak  = GenData(n, mu_peak, rhoPeak', sigma);
        basis = 'Symmlet';

        t = cputime;
        [V,D] = eig(cov(Xpeak));
        V = V(:,p); V = sign(V(idx_peak)) * V;
        rhoPeakHat_st = len_peak * V / norm(V');
        time_peak(i,1) = cputime - t;
        dif_st = rhoPeak - rhoPeakHat_st;
        ase_peak(i,1) = norm(dif_st) / p;

        t = cputime;
        SmPC = SmoothPCA(Xpeak, ps, 10^(-12));
        SmPC = SmPC(:,1); SmPC = sign(SmPC(idx_peak)) * SmPC;
        rhoPeakHat_12 = len_peak * SmPC/norm(SmPC');
        time_peak(i,2) = cputime - t;
        dif_12 = rhoPeak - rhoPeakHat_12;
        ase_peak(i,2) = norm(dif_12) / p;

        t = cputime;
        SmPC = SmoothPCA(Xpeak, ps, 10^(-6));
        SmPC = SmPC(:,1); SmPC = sign(SmPC(idx_peak)) * SmPC;
        rhoPeakHat_6 = len_peak * SmPC/norm(SmPC');
        time_peak(i,3) = cputime - t;
        dif_6 = rhoPeak - rhoPeakHat_6;
        ase_peak(i,3) = norm(dif_6) / p;

        t = cputime;
        AsPC = ASPCA(Xpeak, 8, basis, perc, 'none');
        AsPC = sign(AsPC(idx_peak,1)) * AsPC;
        rhoPeakHat_nt = len_peak * AsPC/norm(AsPC');
        time_peak(i,4) = cputime - t;
        dif_nt = rhoPeak - rhoPeakHat_nt;
        ase_peak(i,4) = norm(dif_nt) / p;

        t = cputime;
        AsPC = ASPCA(Xpeak, 8, basis, perc, 'hard');
        AsPC = sign(AsPC(idx_peak,1)) * AsPC;
        rhoPeakHat_t = len_peak * AsPC/norm(AsPC');
        time_peak(i,5) = cputime - t;
        dif_t = rhoPeak - rhoPeakHat_t;
        ase_peak(i,5) = norm(dif_t) / p;

        %%%%%%%%%%%%%%%%%
        % step function %
        %%%%%%%%%%%%%%%%%
        Xstep  = GenData(n, mu_step, rhoStep', sigma);
        basis = 'Haar';

        t = cputime;
        [V,D] = eig(cov(Xstep));
        V = V(:,p); V = sign(V(idx_step)) * V;
        rhoStepHat_st = len_step * V / norm(V');
        time_step(i,1) = cputime - t;
        dif_st = rhoStep - rhoStepHat_st;
        ase_step(i,1) = norm(dif_st) / p;

        t = cputime;
        SmPC = SmoothPCA(Xstep, ps, 10^(-12));
        SmPC = SmPC(:,1); SmPC = sign(SmPC(idx_step)) * SmPC;
        rhoStepHat_12 = len_step * SmPC/norm(SmPC');
        time_step(i,2) = cputime - t;
        dif_12 = rhoStep - rhoStepHat_12;
        ase_step(i,2) = norm(dif_12) / p;

        t = cputime;
        SmPC = SmoothPCA(Xstep, ps, 10^(-6));
        SmPC = SmPC(:,1); SmPC = sign(SmPC(idx_step)) * SmPC;
        rhoStepHat_6 = len_step * SmPC/norm(SmPC');
        time_step(i,3) = cputime - t;
        dif_6 = rhoStep - rhoStepHat_6;
        ase_step(i,3) = norm(dif_6) / p;

        t = cputime;
        AsPC = ASPCA(Xstep, 8, basis, perc, 'none');
        AsPC = sign(AsPC(idx_step,1)) * AsPC;
        rhoStepHat_nt = len_step * AsPC/norm(AsPC');
        time_step(i,4) = cputime - t;
        dif_nt = rhoStep - rhoStepHat_nt;
        ase_step(i,4) = norm(dif_nt) / p;

        t = cputime;
        AsPC = ASPCA(Xstep, 8, basis, perc, 'hard');
        AsPC = sign(AsPC(idx_step,1)) * AsPC;
        rhoStepHat_t = len_step * AsPC/norm(AsPC');
        time_step(i,5) = cputime - t;
        dif_t = rhoStep - rhoStepHat_t;
        ase_step(i,5) = norm(dif_t) / p;
    end

    %%%%%%%%%%%%%%%%% 
    % produce plots %
    %%%%%%%%%%%%%%%%%

    method = {'Standard' 'Smth12' 'Smth6' 'Sparse' 'Sparse+T'};

    clf;
    subplot(1,2,1);
    boxplot(log10(ase_peak), 'labels', method);
    axis([0 6 -4 -2]);
    axis square;
    title('ASE: 3 peak. 50 iterations.');
    ylabel('log_{10}(ASE)');
    set(gca,'ytick',[-4 -3.5 -3 -2.5 -2]);

    subplot(1,2,2);
    boxplot(log10(ase_step), 'labels', method);
    axis([0 6 -4 -2]);
    axis square;
    title('ASE: step. 50 iterations.');
    ylabel('log_{10}(ASE)');
    set(gca,'ytick',[-4 -3.5 -3 -2.5 -2]);
    
    csvwrite('ase_peak.dat', ase_peak);
    csvwrite('ase_step.dat', ase_step);
    csvwrite('time_peak.dat', time_peak);
    csvwrite('time_step.dat', time_step);
else
    disp('Simulation not run!');
    disp('Please call JL09Figure3 prior to JL09Table1!');
end
