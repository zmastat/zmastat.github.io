% Arthur Y. Lu's original code

function [data] = GenData(n, mu, rho, sigma)
%
% Inputs
%	mu	1 * p vector, mean vector
%	rho	m * p matrix, m principal components
%	sigma	scalar, noise level
% Output
%	data	n * p matrix, n observations
%

n = n;
s = size(rho);
m = s(1);
p = s(2);
Z = normrnd(0, 1, [n p]);
v = normrnd(0, 1, [n m]);

data = zeros(n, p);
for i = 1:n
	data(i, :) = mu + sigma * Z(i, :);
	for j = 1:m 
		data(i, :) = data(i, :) + v(i, j) * rho(j, :);
	end;
end;

