% calculate the loss

% Input: 
%     tPC     truce principal component
%     PC      estimated principal component
% Output:
%     res     loss

function [res] = sqerrorloss(tPC, PC)
    
    a = sum(tPC .* PC);
    if a > 0 
        a = 1;
    else
        a = -1;
    end
    res = sum((tPC - a*PC).^2);

