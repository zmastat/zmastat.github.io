function [PC, k, D, sigma2_hat] = ASPCAalpM(X, L, basis, par, alpha, ...
    postthres, num_eig, sigma2)

% ASPCAalpM --- Sparse PCA with diagonal thresholding rule
% 
% Written by: Zongming Ma 
% Last updated: 2009-10-18
% 
% INPUT 
%   X           n-by-p data matrix
%   L           coarsest level in wavelet transform
%   basis       wavelet basis to be used, choose one from 'Haar', 'Beylkin', 
%               'Coiflet', 'Daubechies', 'Symmlet', 'Vaidyanathan','Battle'
%   par         parameter describing the support length and vanishing
%               moments of the selected wavelet basis
%   alpha       adjustable constant in thresholding rule
%   postthres   post-processing thresholding method
%   num_eig     number of eigenvectors to be computed
%   sigma2      prescribed noise varaince level
% 
% OUTPUT
%   PC          p-by-(num_eig) matrix, columns corresponding to leading
%               eigenvectors
%   k           size of selected subset of coordinates
%   D           estimated leading eigenvalues
%   sigma2_hat  estimated noise variance level 
%               (the same as sigma2 if the later is supplied by the user)


[n,p] = size(X);

if nargin == 6
    num_eig = 1;
end

% DWT of the data: "wc" contains the coefficients
wc = zeros(n,p);
if strcmp(basis,'delta') == 1
    wc = X;
else
    qmf  = MakeONFilter(basis, par);
    for i = 1:n
        wc(i, :) = FWT_PO(X(i, :), L, qmf);
    end
end

% Diagonal thresholding
wc_var = var(wc);
if nargin < 8
    sigma2_hat = median(wc_var);
else
    sigma2_hat = sigma2;
end

pn = max(p, n);
th = sqrt(log(pn)/2);
while(true)
    I_signal = find( wc_var / sigma2_hat  > 1+ alpha * sqrt(2/n) *  th );
    if any(I_signal)
        break;
    end
    th = th / 2;
end

% Reduced PCA [we consider only the first *num_eig* component here]
opts.disp = 0;
if length(I_signal) == 1
    [wcPC,D] = eig(cov(wc(:,I_signal)));
else
    [wcPC,D] = eigs(cov(wc(:,I_signal)), num_eig, 'lm', opts);
end
Q_cur = zeros(p, num_eig);
Q_cur(I_signal,:) = wcPC;
% sigma2_hat = ( sum(wc_var) - sum(diag(D)) ) / (p - num_eig);

% Post-processing thresholding on the PC
if strcmp(postthres, 'none') ~= 1
    if strcmp(postthres, 'hard') == 1
        thresh = @hard_thresholding;
    elseif strcmp(postthres, 'soft') == 1
        thresh = @soft_thresholding;
    else
        disp('*postthres* argument not recognized! Using hard-thresholding as default!');
        thresh = @hard_thresholding;
    end
    for j = 1:num_eig
        k = length(find(Q_cur(:,j)));
        tau_hat = sqrt(sigma2_hat * D(j,j)) / (sqrt(n) * abs(D(j,j) - sigma2_hat));
        th = tau_hat * sqrt(2 * log(k));
        while(true)
            if max(abs(wcPC)) > th
                break;
            end
            th = th / 2;
        end
        Q_cur(:,j) = thresh(Q_cur(:,j), th);
    end
    [Q_cur, R] = qr(Q_cur, 0);
end

k = zeros(1, num_eig);
for j = 1:num_eig
    k(j) = length(find(Q_cur(:,j)));
end

% Transform back to the original basis
PC = zeros(p, num_eig);
if strcmp(basis,'delta') == 1
    PC = Q_cur;
else
    for j = 1:num_eig
        PC(:,j) = IWT_PO(Q_cur(:,j), L, qmf);
    end
end
