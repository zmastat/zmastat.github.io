function [PC, k, m, nspike, d, sigma2_hat, nstep] = ITSPCArank(X, L, basis, par, alpha, ...
    beta, itthres, num_eig, tol, sigma2)

% ITSPCA --- Iterative Thresholding Sparse PCA with Rank Selection
% 
% Written by: Zongming Ma
% Last updated: 2012-09-03
% 
% INPUT
%     X           n-by-p data matrix
%     L           coarsest level in wavelet transform
%     basis       wavelet basis to be used, choose one from 'Haar', 'Beylkin', 
%                 'Coiflet', 'Daubechies', 'Symmlet', 'Vaidyanathan','Battle'
%     par         parameter describing the support length and vanishing
%                 moments of the selected wavelet basis
%     alpha       adjustable constant in the diagonal thresholding step
%     beta        adjustable constant in the iterative thresholding steps
%     itthres     thesholding rule used in the itervative steps
%     num_eig     number of eigenvectors to be computed
%     tol         tolerance level in determining convergence
%     sigma2      prescribed noise varaince level
%     
% OUTPUT
%     PC          p-by-(num_eig) matrix, columns corresponding to leading
%                 eigenvectors
%     k           a vector recording support sizes for the PC's in the
%                 transform domain
%     m           data-based choice of subspace rank
%     nspike      estimated total number of spikes
%     d           estimated leading eigenvalues
%     sigma2_hat  estimated noise variance level 
%                 (the same as sigma2 if the later is supplied by the user)
%     nstep       number of steps to convergence

[n,p] = size(X);

if nargin == 7
    num_eig = 1;
end

% DWT of the data: "wc" contains the coefficients
wc = zeros(n,p);
if strcmp(basis,'delta') == 1
    wc = X;
else
    qmf  = MakeONFilter(basis, par);
    for i = 1:n
        wc(i, :) = FWT_PO(X(i, :), L, qmf);
    end
end

% Compute Johnstone & Lu's DT estimator as the initial value
wc_var = var(wc);
if nargin < 10
    sigma2_hat = median(wc_var);
else
    sigma2_hat = sigma2;
end

pn = max(p, n);
th = sqrt(log(pn)/2);
% while(true)
I_signal = find( wc_var / sigma2_hat  > 1+ alpha * sqrt(2/n) * th );
if numel(I_signal) <= num_eig
    warning('ITSPCA:InitSel',...
        'Number of selected components less than rank!');
    [~, idx] = sort(wc_var,'descend');
    I_signal = idx(1:min(num_eig+10,p));
end
%     th = th / 2;
% end
% opts.disp = 0;
% if length(I_signal) == 1
    [wcPC,D] = eig(cov(wc(:,I_signal)));
% else
%     [wcPC,D] = eigs(cov(wc(:,I_signal)), num_eig, 'lm', opts);
% end
wcPC_aug = zeros(p, length(I_signal));
wcPC_aug(I_signal,:) = wcPC;
d = diag(D);
d = wrev(d);
d = max(d, sigma2_hat .* ones(size(d)));
wcPC_aug = fliplr(wcPC_aug);


k = length(I_signal);
tk2 = 6*log(pn)/n + 2*k*(log(p)+1)/n;
dk = sqrt(k/n) + sqrt(tk2);
% disp((1+dk)^2);
nspike = sum(d > (1 + dk)^2);
if nspike == 0
    disp('nspike = 0! Reset to 1.');
    nspike = 1;
end
% disp(['nspike = ', int2str(nspike)]);
kmax = 15;
kk = - (d(1) - sigma2_hat)./diff(d);
kk = kk(1:nspike);
m = find(kk <= kmax, 1, 'last');
% disp(['m = ', int2str(m)]);
if m < num_eig;
    disp('ITSPCA: num_eig might be overspecified!');
end

wcPC_aug = wcPC_aug(:,1:num_eig);

% Iterative thresholding algorithm
Q_old = wcPC_aug;
Q_cur = Q_old;
nstep = 0;
% Scaled sample covariance matrix
S = cov(wc) / sigma2_hat;
d = d / sigma2_hat;
th = beta * sqrt(log(pn) / n);

if strcmp(itthres, 'hard') == 1
    thresh = @hard_thresholding;
elseif strcmp(itthres, 'soft') == 1
    thresh = @soft_thresholding;
else
    warning('ITSPCA:Thresh',...
        'Argument *itthres* not recognized! Using hard-thresholding as default!');
    thresh = @hard_thresholding;
end

dist = 1; Ks = 50;
if nargin < 9
    tol = 1e-12;
    Ks = 1.1 * d(1) / ( d(num_eig) - d(num_eig+1) ) * ( (1+1/log(2)) * log(n) + max(0, log( (d(1)-1)^2 / d(1) )) );
%     disp(['Ks = ', int2str(floor(Ks))]);
end

while (nstep == 0 || (dist^2 > tol && nstep < Ks) )
    Q_old = Q_cur;
    Q_cur = S * Q_old;
    for j = 1:num_eig
        Q_cur(:,j) = thresh(Q_cur(:,j), th * sqrt(d(j)))';
%         N = length(find(Q_cur(:,j)));
%         d(j) = norm(Q_cur(:,j));
%         g = N / n;
%         if (d(j)+1-g)^2 - 4*d(j) >= 0
%             d(j) = 1/2 * (sqrt((d(j)+1-g)^2 - 4*d(j)) + (d(j)+1-g));
%         end
    end
    % in case we obtain zero-vector!
    if any(find(Q_cur))==0
        Q_cur = Q_old;
        break
    end
    [Q_cur, ~] = qr(Q_cur, 0);
    nstep = nstep + 1;
    dist = subsp_dist(Q_old, Q_cur);
    if dist == 1
        warning('ITSPCA:OverThresh',...
            'Singularity caused by thresholding!');
    end
end

k = zeros(1, num_eig);
for j = 1:num_eig
    k(j) = length(find(Q_cur(:,j)));
end

% disp(d');

% Transform back to the original basis
PC = zeros(p, num_eig);
if strcmp(basis,'delta') == 1
    PC = Q_cur;
else
    for j = 1:num_eig
        PC(:,j) = IWT_PO(Q_cur(:,j), L, qmf);
    end
end
