function rb = riskbound(rho,lam,epsilon)

rb = zeros(1,length(rho));

rzero = 2.*(lam*normpdf(lam) + 1 - normcdf(lam));

lo = ( abs(rho) < lam.*epsilon );
rb(lo) = 1.2 .* (rzero.*epsilon.^2 + rho(lo).^2);

hi = ( abs(rho) >= lam.*epsilon);
rb(hi) = epsilon.^2 + (rho(hi).^2).*(1-normcdf(-lam + abs(rho(hi))./epsilon));
