function [data] = SimuData(n, mu, rho, lambda, sigma, noise, df)
%
% Inputs
%	mu      1 * p vector, mean vector
%	rho     m * p matrix, m principal components
%   lambda  1 * m vector, square root of spikes
%	sigma	scalar, noise level
%   noise   the distribution of the noise
%   df      the degrees of freedom of the noise (for student's t)
% Output
%	data	n * p matrix, n observations
%

if nargin == 5
    df = 3;
end

s = size(rho);
m = s(1);
p = s(2);

if strcmp(noise, 'normal') == 1
    Z = normrnd(0, 1, [n p]);
elseif strcmp(noise, 'bern') == 1
    Z = 2 * binornd(1, ones(n,p)./2) - 1;
elseif strcmp(noise, 'dexp') == 1
    Z = exprnd(1, [n p]) / sqrt(2);
    Z = Z .* (2 * binornd(1, ones(n,p)./2) - 1);
elseif strcmp(noise, 't') == 1
    if df <= 2
        disp('*df* too small for the variance to be finite! Using df = 3 as default!');
        df = 3;
    end
    Z = trnd(df, [n, p]);
    Z = Z ./ sqrt(df/(df-2));
else
    disp('*noise* argument not recognized! Using normal noise as default!');
    Z = normrnd(0, 1, [n p]);
end

V = normrnd(0, 1, [n m]);

data = repmat(mu, n, 1) + repmat(lambda, n, 1) .* V * rho + sigma * Z;

