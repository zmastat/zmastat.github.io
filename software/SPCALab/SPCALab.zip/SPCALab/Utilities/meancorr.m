function y = meancorr(x)

% x is n x p data matrix,  n cases of p-vector

dim = size(x);
n = dim(1);
y = x - ones(n,1) * mean(x,1);