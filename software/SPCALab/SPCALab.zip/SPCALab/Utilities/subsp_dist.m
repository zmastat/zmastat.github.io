% the squared distance between two subspaces

function [dist] = subsp_dist(A, B)

[A, R] = qr(A, 0);
[B, R] = qr(B, 0);

overlap = svd(A' * B);
overlap = overlap(end);
dist = 1 - overlap^2;
