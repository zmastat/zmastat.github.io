function [PC k] = CORR_PCA_Algorithm(data, L, basis, alpha, dothres, num_eig)
% function [PC k] = CORR_PCA_Algorithm(data, L, basis, alpha, dothres, num_eig)
% PC = first num_eig principal components after possible thresholding
% Written by Boaz Nadler
% INPUT: data  - n by p matrix of observations
%        basis - basis to transform the data to.
%        alpha - confidence level, 0.02 is a good choice.
%        dothres - what type of thresholding to perform, 'none' is ok.
%        num_eig - number of eigenvalues to report
% OUTPUT: PC - first num_eig principal components
%          k - number of features chosen to compute them.

if nargin==5 num_eig= 1; end;

[n,p] = size(data);

% Step 1: Select Basis
% wavelet transformation: "wc" contains the coefficients
if strcmp(basis,'delta')==1
  wc = data;
else
  qmf = MakeONFilter(basis, 8);
  wc = zeros(n,p);
  for i = 1:n
      wc(i, :) = FWT_PO(data(i, :), L, qmf);
  end;
end

wc_var = var(wc);
sigma2_hat = median(wc_var);
%fprintf('CORR_PCA: sigma2_hat %f\n',sigma2_hat);

% find indexes with variance significantly above noise threshold
% O(sqrt(2 log(p)) according to Extreme Value Theory.
C_EVT = log(1/alpha);
th = sqrt(2*log(p)) - log(4*pi*log(p)) / ( 2*sqrt(2*log(p)) ) + C_EVT / sqrt(2*log(p)) ;
I_signal = find( wc_var / sigma2_hat  > 1+ sqrt(2/n) *  th );

I_out = setdiff(1:p,I_signal);
p_out = length(I_out);

k = length(I_signal);
mu_wc = mean(wc); wc_center = wc-repmat(mu_wc,n,1); S12 = wc_center' * wc_center(:,I_signal) / (n-1) ;
Sigma_S_n = 1./sqrt(wc_var);
R12 = repmat(Sigma_S_n',1,k) .* S12 .* repmat(Sigma_S_n(I_signal),p,1) ;
ES = sum((R12.^2)') / k;
ES(I_signal) = 1;        % signal variables already found have high values in ES - so are chosen later

C_EVT = log(1/alpha);
th = sqrt(2*log(p_out)) - log(4*pi*log(p_out)) / ( 2*sqrt(2*log(p_out)) ) + C_EVT / sqrt(2*log(p_out)) ;

idx_signal = find(ES > 1/(n-1) * ( 1 + sqrt(2) * th) ) ;

I = idx_signal;

k = length(I);

% Step 3: PCA [we consider only the first component here]
%[wcPC,D] = eig(S_n(idx_small,idx_small));

opts.disp = 0;
[wcPC,D] = eigs(cov(wc(:,I)),num_eig,'lm',opts);

wcPC_before_threshold = wcPC;

% Step 4: Thresholding
rhonorm2_hat = sum(wc_var) - p * sigma2_hat;
tau_hat = sqrt(sigma2_hat * (rhonorm2_hat + sigma2_hat)) / (sqrt(n) * rhonorm2_hat);
th = tau_hat * sqrt(2 * log(k));
if strcmp(dothres, 'hard')
  wcPC = hard_thresholding(wcPC, th);
elseif strcmp(dothres, 'soft')
  wcPC = soft_thresholding(wcPC, th);
elseif strcmp(dothres, 'none')
  disp('Warning in CORR_PCA: No thresholding performed!');
  th = 0;
else
  disp('Could not understand your choice of *dothres*! No thresholding performed!');
  th = 0;
end

PC = zeros(p,num_eig);
% Step 5: Reconstruction
if strcmp(basis,'delta')==1
  PC(I,:) = wcPC;
else
  wcPC_aug = zeros(p, num_eig);
  wcPC_aug(I,:) = wcPC;
  for j=1:num_eig
      PC(:,j) = IWT_PO(wcPC_aug(:,j), L, qmf);
  end
end