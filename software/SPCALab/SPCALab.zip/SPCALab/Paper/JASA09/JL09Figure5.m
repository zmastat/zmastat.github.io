% Figure 5 of Johnstone and Lu (2009):
% ECG Examples with 1st PCs, sample # 1 and 2.

fprintf('This function reproduces Fig.5 of Johnstone & Lu (2009).\n\n');
fprintf('Processing...\n\n');

basis = 'Symmlet';
perc = 0.95;

load ('ECGdatamatrix1');
load ('ECGdatamatrix2');

% standard PCA for matrix 1
meancurve1 = mean(ECGdatamatrix1);
[SamplePc1,D] = eigs(cov(ECGdatamatrix1),eye(512),1);
SamplePc1 = sign(SamplePc1(150)) * SamplePc1;

% standard PCA for matrix 2
meancurve2 = mean(ECGdatamatrix2);
[SamplePc2,D] = eigs(cov(ECGdatamatrix2),eye(512),1);
SamplePc2 = sign(SamplePc2(150)) * SamplePc2;

% sparse PCA + T for matrix 1
Y = meancorr(ECGdatamatrix1);
[U,S,V] = svds(Y,1);
sd1 = sqrt(var(U)) * S;
[SparsePc1, k1, th1, sigma2_1] = ASPCA(ECGdatamatrix1, 5, basis, perc, 'hard');
SparsePc1 = sign(SparsePc1(150)) * SparsePc1;

% sparse PCA + T for matrix 2
Y = meancorr(ECGdatamatrix2);
[U,S,V] = svds(Y,1);
sd2 = sqrt(var(U)) * S;
[SparsePc2, k2, th2, sigma2_2] = ASPCA(ECGdatamatrix2, 5, basis, perc, 'hard');
SparsePc2 = sign(SparsePc2(150)) * SparsePc2;

% make plots

clf;
subplot(2,3,1);
plot(meancurve1, 'black');
hold on;
plot(meancurve1 - 2 .* sd1 .* SparsePc1', 'r');
plot(meancurve1 + 2 .* sd1 .* SparsePc1', 'g');
axis([0 512 -300 1400]);
h=title('a) Ave curve of sample 1');

subplot(2,3,2);
plot(meancurve1, 'black');
hold on;
plot(meancurve1 - 2 .* sd1 .* SparsePc1', 'r');
plot(meancurve1 + 2 .* sd1 .* SparsePc1', 'g');
axis([120 220 -300 1400]);
h=title('b) Ave curve of sample 1');

subplot(2,3,3);
hl1 = line(1:512,SamplePc1,'Color','r'); hold on;
axis([0 512 -0.7 0.3]);
ax1 = gca;
set(ax1,'XColor','r','YColor','r')
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
hl2 = line(1:512,SparsePc1,'Color','k','Parent',ax2); hold on;
axis([0 512 -0.3 0.7]);
h=title('c) 1st p.c. for sample 1');

subplot(2,3,4);
plot(meancurve2, 'black');
hold on;
plot(meancurve2 - 2 .* sd2 .* SparsePc2', 'r');
plot(meancurve2 + 2 .* sd2 .* SparsePc2', 'g');
axis([0 512 -300 1400]);
h=title('d) Ave curve of sample 2');

subplot(2,3,5);
plot(meancurve2, 'black');
hold on;
plot(meancurve2 - 2 .* sd2 .* SparsePc2', 'r');
plot(meancurve2 + 2 .* sd2 .* SparsePc2', 'g');
axis([120 220 -300 1400]);
h=title('e) Ave curve of sample 2');

subplot(2,3,6);
hl1 = line(1:512,SamplePc2,'Color','r'); hold on;
axis([0 512 -0.35 0.125]);
ax1 = gca;
set(ax1,'XColor','r','YColor','r')
ax2 = axes('Position',get(ax1,'Position'),...
           'XAxisLocation','top',...
           'YAxisLocation','right',...
           'Color','none',...
           'XColor','k','YColor','k');
hl2 = line(1:512,SparsePc2,'Color','k','Parent',ax2); hold on;
axis([0 512 -0.15 0.325]);
h=title('f) 1st p.c. for sample 2');

