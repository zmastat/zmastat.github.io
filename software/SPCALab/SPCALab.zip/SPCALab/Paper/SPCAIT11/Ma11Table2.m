% Table 2 of Ma (2011):
% Comparison of sparse PCA methods in multiple spike settings: average loss
% in estimation.

disp('This function reproduces Table 2 of Ma (2011).');
R = input('Have you run the multiple spike simulation? [Yes/No]\n', 's');

if strcmp(R,'') || strcmp(R,'Yes') || strcmp(R,'yes') || strcmp(R,'y') || strcmp(R,'Y') || strcmp(R,'YES')
    lambda2 = [100,  75,  50,  25;
        60,  55,  50,  45;
        30,  27,  25,  22;
        30,  20,  10,   5];
    
    result = zeros(size(lambda2,1), 4*size(lambda2,2));
    for i = 1:size(lambda2,1)
        for j = 1:size(lambda2,2)
            direc = strcat(cd,'/Paper/SPCAIT11');
            file = strcat(direc, '/multiple/St_Po_Pe_Si_lambda2_', ...
                num2str(lambda2(i,:)), '_', num2str(j), ...
                'normal_0_niter100_Symmlet8_itspca_hard150.csv');
            exprcd = csvread(file);
            result(i,j) = mean(exprcd(:,3+j));
            
            file = strcat(direc, '/multiple/St_Po_Pe_Si_lambda2_', ...
                num2str(lambda2(i,:)), '_', num2str(j), ...
                'normal_0_niter100_Symmlet8_augpca_hard200.csv');
            exprcd = csvread(file);
            result(i,1*size(lambda2,2)+j) = mean(exprcd(:,3+j));
            
            file = strcat(direc, '/multiple/St_Po_Pe_Si_lambda2_', ...
                num2str(lambda2(i,:)), '_', num2str(j), ...
                'normal_0_niter100_Symmlet8_corpca_none002.csv');
            exprcd = csvread(file);
            result(i,2*size(lambda2,2)+j) = mean(exprcd(:,3+j));
            
            file = strcat(direc, '/multiple/St_Po_Pe_Si_lambda2_', ...
                num2str(lambda2(i,:)), '_', num2str(j), ...
                'normal_0_niter100_Symmlet8_jlspca_hard100.csv');
            exprcd = csvread(file);
            result(i,3*size(lambda2,2)+j) = mean(exprcd(:,3+j));
        end
    end
    
    table = zeros(16, 5);
    table( 1: 4, 2:end) = reshape(result(1,:),4,4);
    table( 5: 8, 2:end) = reshape(result(2,:),4,4);
    table( 9:12, 2:end) = reshape(result(3,:),4,4);
    table(13:16, 2:end) = reshape(result(4,:),4,4);
    table(:,1) = repmat(1:4,[1,4])';
    
    disp(' ');
    disp('          ===== Table 2 of Ma (2011) =====');
    disp(' ');
    disp('       m      ITSPCA   AUGSPCA   CORSPCA    DTSPCA');
    disp('lambda^2 = (100, 75, 50, 25)');
    disp(table(1:4,:));
    disp('lambda^2 = ( 60, 55, 50, 45)');
    disp(table(5:8,:));
    disp('lambda^2 = ( 30, 27, 25, 22)');
    disp(table(9:12,:));
    disp('lambda^2 = ( 30, 20, 10,  5)');
    disp(table(13:16,:));
    
    % latex(table, '%.4f');
    
else
    disp('Table 2 could not be reproduced! Run simu_multiple.m first!');
end