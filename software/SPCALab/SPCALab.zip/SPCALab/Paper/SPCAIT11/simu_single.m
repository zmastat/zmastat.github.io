% Code for single spike simulation.
% Results needed for reproducing Table 1.
% The whole simulation could take several hours.

niter = 100;

load rhoPeak;
load rhoStepNew;
load rhoPiecePoly;
load rhoSing;

lambda2 = [100, 25, 10, 5, 2]';

tol = 1/(1024^2);

randn('state', 11);
disp('Single spike: Peak function');
rho = rhoPeak/norm(rhoPeak);
for i = 1:length(lambda2)
  xp_SPCArank(rho, lambda2(i), 1, niter, 'normal', 0, 'Symmlet', 8, tol, ...
          'Paper/SPCAIT11/single/Peak')
end


randn('state', 11);
disp('Single spike: Step function');
rho = rhoStepNew/norm(rhoStepNew);
for i = 1:length(lambda2)
  xp_SPCArank(rho, lambda2(i), 1, niter, 'normal', 0, 'Symmlet', 8, tol, ...
          'Paper/SPCAIT11/single/Step')
end


randn('state', 11);
disp('Single spike: Piecewise-Polynomial function');
rho = rhoPiecePoly;
for i = 1:length(lambda2)
  xp_SPCArank(rho, lambda2(i), 1, niter, 'normal', 0, 'Symmlet', 8, tol, ...
          'Paper/SPCAIT11/single/Poly')
end


randn('state', 11);
disp('Single spike: Sing function');
rho = rhoSing;
for i = 1:length(lambda2)
  xp_SPCArank(rho, lambda2(i), 1, niter, 'normal', 0, 'Symmlet', 8, tol, ...
          'Paper/SPCAIT11/single/Sing')
end

