% Code for multiple spike simulation. 
% Results needed for reproducing Table 2.
% The whole simulation could take several hours.

niter = 100;

load rhoPeak;
load rhoStepNew;
load rhoPiecePoly;
load rhoSing;

noise = 'normal';
df    = 0;
basis = 'Symmlet';
par   = 8;
tol   = 1e-6;


% Step/Poly/Peak/Sing      

rho = [rhoStepNew rhoPiecePoly rhoPeak rhoSing];
[rho, R] = qr(rho,0);
lambda2 = [100,  75,  50,  25; 
            60,  55,  50,  45;
            30,  27,  25,  22; 
            30,  20,  10,   5];

[p, nsig] = size(rho);
nl = size(lambda2, 1);

for j = 1:nl
    for i = 1:nsig
        randn('state', 11);
        xp_SPCA(rho, lambda2(j,:), i, niter, noise, df, basis, par, tol, ...
                'multiple/St_Po_Pe_Si'); 
    end
end        

       
