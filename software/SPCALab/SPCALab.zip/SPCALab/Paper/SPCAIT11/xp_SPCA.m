function xp_SPCA(rho, lambda2, num_eig, niter, noise, df, basis, ...
                 par, tol, direc)

if strcmp(noise, 't') ~= 1
  df = 0;
end

if size(rho,2) < num_eig
    rhonew = zeros(size(rho,1), num_eig);
    rhonew(:,1:size(rho,2)) = rho;
else
    rhonew = rho;
end

% set seed
% state = 100;
% randn('state', state);

n = 1024;
p = 2048;

alpha = 3;

res_itspca_hard150 = zeros(niter, 3 + 2 * num_eig);
res_itspca_hard173 = zeros(niter, 3 + 2 * num_eig);

res_augpca_hard200 = zeros(niter, 3 + 2 * num_eig);
% res_augpca_none200 = zeros(niter, 3 + 2 * num_eig);

% res_corpca_none100 = zeros(niter, 3 + 2 * num_eig);
res_corpca_none002 = zeros(niter, 3 + 2 * num_eig);

% res_jlspca_none100 = zeros(niter, 3 + 2 * num_eig);
res_jlspca_hard100 = zeros(niter, 3 + 2 * num_eig);  

disp('lambda2 = ');
disp(lambda2);
disp('Current iteration:');
  
for i = 1:niter
    
  disp(int2str(i));
  X = SimuData(n, zeros(1,p), rho', sqrt(lambda2), 1, noise, df);
  
  % ITSPCA (hard-thr, 1.5)
  t = cputime;
  [PC, k, nstep] = ITSPCA(X, 4, basis, par, alpha, 1.5, 'hard', ...
                          num_eig, tol);
  tt = cputime - t;
  res_itspca_hard150(i ,1:(3+num_eig)) = [nstep k tt subsp_dist(PC, ...
                                                    rhonew(:,1:num_eig))];  
  for m = 1:num_eig
    res_itspca_hard150(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m));
  end
  
  % ITSPCA (hard-thr, root 3)
  t = cputime;
  [PC, k, nstep] = ITSPCA(X, 4, basis, par, alpha, sqrt(3), 'hard', ...
                          num_eig, tol);
  tt = cputime - t;
  res_itspca_hard173(i ,1:(3+num_eig)) = [nstep k tt subsp_dist(PC, ...
                                                    rhonew(:,1:num_eig))];  
  for m = 1:num_eig
    res_itspca_hard173(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m));
  end
  
  nstep = 0;
  
  % AUGSPCA (hard-thr, 2.0)
  t = cputime;
  [PC, ~, k_th] = AugSPCA(X, 4, basis, par, alpha, 2, 'hard', ...
                          num_eig);
  tt = cputime - t;
  res_augpca_hard200(i ,1:(3+num_eig)) = [nstep k_th tt subsp_dist(PC, ...
                                                    rhonew(:,1:num_eig))];   
  for m = 1:num_eig
    res_augpca_hard200(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m));
  end
  
%   % AUGSPCA (none-thr, 2.0)
%   t = cputime;
%   [PC, ~, k_th] = AugSPCA(X, 4, basis, par, alpha, 2, 'none', ...
%                           num_eig);
%   tt = cputime - t;
%   res_augpca_none200(i ,1:(3+num_eig)) = [nstep k_th tt subsp_dist(PC, ...
%                                                     rhonew(:,1:num_eig))];   
%   for m = 1:num_eig
%     res_augpca_none200(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m));
%   end
  
%   % CORRPCA (none, 100)
%   t = cputime;
%   [PC, k] = CORR_PCA(X, 4, basis, 1, 'none', num_eig);
%   tt = cputime - t;
%   res_corpca_none100(i, 1:(3+num_eig)) = [nstep k*ones(1, num_eig) ...
%                       tt subsp_dist(PC, rhonew(:,1:num_eig))]; 
%   for m = 1:num_eig
%     res_corpca_none100(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m)); 
%   end
  
  % CORRPCA (none, 002)
  t = cputime;
  [PC, k] = CORR_PCA(X, 4, basis, 0.02, 'none', num_eig);
  tt = cputime - t;
  res_corpca_none002(i, 1:(3+num_eig)) = [nstep k*ones(1, num_eig) ...
                      tt subsp_dist(PC, rhonew(:,1:num_eig))]; 
  for m = 1:num_eig
    res_corpca_none002(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m),PC(:,m)); 
  end
  
%   % JLSPCA (none, 100)
%   t = cputime;
%   [PC, k] = ASPCAalpM(X, 4, basis, par, 1, 'none', num_eig);
%   tt = cputime - t;
%   res_jlspca_none100(i,1:(3+num_eig)) = [nstep k tt subsp_dist(PC, ...
%                                                     rhonew(:,1:num_eig))]; 
%   for m = 1:num_eig
%     res_jlspca_none100(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m), PC(:,m));
%   end
  
  % JLSPCA (hard, 100)
  t = cputime;
  [PC, k] = ASPCAalpM(X, 4, basis, par, 1, 'hard', num_eig);
  tt = cputime - t;
  res_jlspca_hard100(i,1:(3+num_eig)) = [nstep k tt subsp_dist(PC, ...
                                                    rhonew(:,1:num_eig))]; 
  for m = 1:num_eig
    res_jlspca_hard100(i, (3+num_eig)+m) = sqerrorloss(rhonew(:,m), PC(:,m));
  end
  
end

csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
                noise, '_', num2str(df), '_niter', num2str(niter), ...
                '_', basis, num2str(par), '_itspca_hard150.csv'), ...
         res_itspca_hard150);

csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
                noise, '_', num2str(df), '_niter', num2str(niter), ...
                '_', basis, num2str(par), '_itspca_hard173.csv'), ...
         res_itspca_hard173);

csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
                noise, '_', num2str(df), '_niter', num2str(niter), ...
                '_', basis, num2str(par), '_augpca_hard200.csv'), ...
         res_augpca_hard200);

% csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
%                 noise, '_', num2str(df), '_niter', num2str(niter), ...
%                 '_', basis, num2str(par), '_augpca_none200.csv'), ...
%          res_augpca_none200);

% csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
%                 noise, '_', num2str(df), '_niter', num2str(niter), ...
%                 '_', basis, num2str(par), '_corpca_none100.csv'), ...
%          res_corpca_none100);

csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
                noise, '_', num2str(df), '_niter', num2str(niter), ...
                '_', basis, num2str(par), '_corpca_none002.csv'), ...
         res_corpca_none002);

% csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
%                 noise, '_', num2str(df), '_niter', num2str(niter), ...
%                 '_', basis, num2str(par), '_jlspca_none100.csv'), ...
%          res_jlspca_none100);

csvwrite(strcat(direc, '_lambda2_', num2str(lambda2), '_', num2str(num_eig), ...
                noise, '_', num2str(df), '_niter', num2str(niter), ...
                '_', basis, num2str(par), '_jlspca_hard100.csv'), ...
         res_jlspca_hard100);




