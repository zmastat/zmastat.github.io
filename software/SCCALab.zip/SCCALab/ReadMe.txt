SCCALab ReadMe

1. This package depends on the TFOCS package. Please download TFOCS ( available at http://cvxr.com/tfocs/ ), and ensure that both packages are added to your Matlab path library. 

2. Please run scca_example.m to see an example.

3. This Matlab package is for realizing the algorithm proposed in the following paper. Please cite the paper if you use the code for your research purpose.

Gao, Ma and Zhou (2014) 
Sparse CCA: Adaptive estimation and computational barriers.
arXiv:1409.8565.