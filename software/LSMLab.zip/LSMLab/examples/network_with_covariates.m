%network with covariates with lawyer dataset as an example
%load data
load('lawyer_CC.mat');

%include practice type as the covariate 
X = practice;

%set latent space dimension as the number of communities in the network
k = length(unique(label));

%initialize by singular value thresholding with covariate
[Z0, alpha0, beta0]=init_SVT_X(A, k, X);

%run the non-convex estimation algorithm with covariate
[Z, alpha] = nonconvex_X(A, Z0, alpha0, beta0, X);

%compute the clustering error
error = clustering_error(Z, label) %0.087, 6 mis-clustered nodes

%%
%without including practice as the covariates
%initialize by singular value thresholding
[Z0, alpha0]=init_SVT(A, k);

%run the non-convex estimation algorithm
[Z, alpha] = nonconvex(A, Z0, alpha0);

%compute the clustering error
error = clustering_error(Z, label) %0.1739, 12 mis-clustered nodes
