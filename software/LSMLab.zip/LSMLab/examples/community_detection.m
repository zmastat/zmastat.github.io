%Political blog
%load data
% A: adjacency matrix, label: community membership vecotor
load('politicalblog_CC.mat') 

%set latent space dimension as the number of communities in the network
k = length(unique(label));

%initialize by singular value thresholding
[Z0, alpha0]=init_SVT(A, k);

%run the non-convex estimation algorithm
[Z, alpha] = nonconvex(A, Z0, alpha0);

%compute the clustering error
error = clustering_error(Z, label) %0.0475

%%
%Simmons college 
load('simmons_CC.mat')
k = length(unique(label));
[Z0, alpha0]=init_SVT(A, k);
[Z, alpha] = nonconvex(A, Z0, alpha0);
error = clustering_error(Z, label) %0.1179

%%
%Caltech
load('caltech_CC.mat')
k = length(unique(label));
[Z0, alpha0]=init_SVT(A, k);
[Z, alpha] = nonconvex(A, Z0, alpha0);
error = clustering_error(Z, label)  %0.1797