library(grpreg)
if (packageVersion("grpreg") != '2.4.0'){
  warning("To reproduce the simulation results, please use version 2.4.0 of the grpreg package!")
}
library(MASS)
############################################################
############################################################

#main function
SARRS <- function(Y,X,r,lam,ptype,V0=NULL){

n= dim(X)[1]
p= dim(X)[2]
m= dim(Y)[2]
group = rep(1:(p+1),r)

if(is.null(V0)){
	V0 = svd(Y,nu=r,nv=r)$v
}

XX = kronecker(diag(rep(1,r)),cbind(X,1))
YY = Y %*% V0
YY = as.vector(YY)
fit1 = grpreg(XX,YY,group,lambda=lam, penalty= ptype, family="gaussian")
B1= matrix(fit1$beta[-1],nrow=p+1,ncol=r)
B1[p+1,]=B1[p+1,]+fit1$beta[1]
XB=cbind(X,1) %*% matrix(B1,nrow=p+1,ncol=r)

U1= svd(XB,nu=r,nv=r)$u
tmp= U1%*%t(U1)%*%Y
V1= svd(tmp,nu=r,nv=r)$v

YY = Y %*% V1
YY = as.vector(YY)
fit2 = grpreg(XX,YY,group,lambda=lam, penalty= ptype, family="gaussian")
B2= matrix(fit2$beta[-1],nrow=p+1,ncol=r)
B2[p+1,]=B2[p+1,]+fit2$beta[1]

Ahat= B2 %*% t(V1)
return(list(Ahat=Ahat))
}
############################################################


############################################################
############################################################
#generate the simulated data
gnrt <-function(n,nvld,ntst,nrow, p, m, r, rho,sigma,b){
	
	A=matrix(0,p,m)
	B0=matrix(rnorm(nrow*r),nrow,r)
	B1=matrix(rnorm(r*m),r,m)
	A[1:nrow,]=b*B0%*%B1

	Sigma=matrix(1,p,p)
	for(j in 1:p) for (k in 1:p) Sigma[j,k]=rho^abs(j-k)

	X=mvrnorm(n,rep(0,p),Sigma)	
	E=matrix(rnorm(n*m),n,m)
	Y=X%*%A + E
	
	Xvld=mvrnorm(nvld,rep(0,p),Sigma)	
	Evld=matrix(rnorm(nvld*m),nvld,m)
	Yvld=Xvld%*%A + Evld
	
	Xtst=mvrnorm(ntst,rep(0,p),Sigma)	
	Etst=matrix(rnorm(ntst*m),ntst,m)
	Ytst=Xtst%*%A + Etst
	
	return(list(Y=Y,X=X,A=A,r=r,Yvld=Yvld,Xvld=Xvld,Ytst=Ytst,Xtst=Xtst))
}

error <- function(Ahat,A,X,Y){
	
	p=dim(Ahat)[1]-1
	err.pred=mean((Y-cbind(X,1)%*%Ahat)^2)
	err.est=mean((A-Ahat[-(p+1),])^2)
	
	nz.Ahat=which(rowSums(Ahat[-(p+1),]^2)!=0)
	nz.A=which(rowSums(A^2)!=0)

	shat = length(nz.Ahat)
	M = 1-length(intersect(nz.A,nz.Ahat))/length(nz.A)
	FA = 1-length(intersect(nz.A,nz.Ahat))/length(nz.Ahat)
	return(list(err.pred=err.pred,err.est=err.est,shat=shat,M=M,FA=FA))
}

