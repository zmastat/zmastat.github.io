
source("SARRS.r")
simu <-function(nrep, n, nvld, ntst, nrow, p, m, r, rho, sigma, b, seed=NULL,ifprint=F){

if(!is.null(seed)) set.seed(seed)	

penal.const=1:50/50
penal.type=c("grLasso","grMCP")
err.result=array(NA, dim=c(nrep, length(penal.type),length(penal.const)+1,4),
			dimnames=list(1:nrep,penal.type,c(penal.const,"opt"),
			c("err.pred","err.est","shat","rhat")))

for(kk in 1:nrep){

if(ifprint==F & (kk%%10==1)) cat("\n replication: ", kk) 
if(ifprint==F & (kk%%10!=1)) cat(" ",kk) 
if(ifprint==T) cat("replication", kk,  date(),"\n")

#generate dataset
{
data=gnrt(n, nvld, ntst, nrow, p, m, r, rho, sigma, b)
Y=data$Y
X=data$X
A=data$A
r=data$r
Yvld=data$Yvld
Xvld=data$Xvld
Ytst=data$Ytst
Xtst=data$Xtst
}

if(ifprint==T) cat("data generated.","\n")

#estimate noise variance
Minv = ginv(t(Xvld)%*%Xvld)
Pvld=Xvld%*%Minv%*%t(Xvld)
sigmahat = sqrt(sum((Yvld-Pvld%*%Yvld)^2)/(nvld*m-min(nvld,p)*m))

#estimate rank
P=X%*% ginv(t(X)%*%X) %*%t(X)
rhat = sum(svd(P%*%Y)$d > sigmahat*(sqrt(2*m)+sqrt(2*min(n,p))))
err.result[kk,1,length(penal.const)+1,4]=rhat

lam0=2*sigmahat*max(sqrt(colSums(X^2)))/n/rhat*(sqrt(rhat)+2*sqrt(log(p)))
if(ifprint==T)  cat("Initialized.","\n")

for(jj in 1:length(penal.type)){

err.cur=Inf
Ahat.cur=NA		##record the best penal.const
for(rr in 1:length(penal.const)){

	V0 = svd(P%*%Y,nu=rhat,nv=rhat)$v
	objtmp = SARRS(Y,X,rhat, lam0*penal.const[rr], penal.type[jj],V0)
	Ahat.new = 	objtmp$Ahat
	err.new = mean((Yvld-(cbind(Xvld,1) %*% Ahat.new))^2)
	
	err = error(Ahat.new,A, Xtst, Ytst)
	err.result[kk,jj,rr,1]=err$err.pred
	err.result[kk,jj,rr,2]=err$err.est	
	err.result[kk,jj,rr,3]=err$shat
	
	if(err.new < err.cur) {
		Ahat.cur=Ahat.new
		err.cur= err.new
		obj=objtmp
	}
}

Ahat=Ahat.cur
err = error(Ahat,A,Xtst,Ytst)
err.result[kk,jj,length(penal.const)+1,1]=err$err.pred
err.result[kk,jj,length(penal.const)+1,2]=err$err.est	
err.result[kk,jj,length(penal.const)+1,3]=err$shat

if(ifprint==T) 
	cat(penal.type[jj], "\t pred err =",
		round(err$err.pred,3), "\t est err =",round(err$err.est,3),"\n")
}
if(ifprint==T) cat("\n")
}

cat("\n")
return(err.result)
}



printtable <- function(err.result){
penal.const=dimnames(err.result)[[3]]
penal.type=dimnames(err.result)[[2]]
err.mean=apply(err.result,c(2,3,4),mean)
err.sd=apply(err.result,c(2,3,4),sd)
cat("\nEstimated rank: \t $",
	round(mean(err.result[,1,length(penal.const),4]),2),"\\pm", 
	round(sd(err.result[,1,length(penal.const),4]),2),"$ \n")
for(jj in 1:length(penal.type)){
cat(penal.type[jj],
	"& $", round(err.mean[jj,length(penal.const),1],3), "\\pm",
	round(err.sd[jj,length(penal.const),1],3), " $ ",
	"& $", round(err.mean[jj,length(penal.const),2],3), "\\pm",
	round(err.sd[jj,length(penal.const),2],3), " $ ",
	"& $", round(err.mean[jj,length(penal.const),3],2), "\\pm",
	round(err.sd[jj,length(penal.const),3],2), #" $ ",
	"$ \\\\\n")
}
}


## generate the simulation results in the paper
nrep=50; nvld=10000
nrow=15; rho=0.1; sigma=1

n=30; p=100; m=10; r=2; b=0.5; seed=1984+m+nrow+p+n+r+b*10; ntst=n
err.result = simu(nrep,n,nvld,ntst,nrow,p,m,r,rho,sigma,b,seed)
printtable(err.result)
n=30; p=100; m=10; r=2; b=1; seed=1984+m+nrow+p+n+r+b*10; ntst=n
err.result = simu(nrep,n,nvld,ntst,nrow,p,m,r,rho,sigma,b,seed)
printtable(err.result)
n=100; p=25; m=25; r=5; b=0.2; seed=1984+m+nrow+p+n+r+b*10; ntst=n
err.result = simu(nrep,n,nvld,ntst,nrow,p,m,r,rho,sigma,b,seed)
printtable(err.result)
n=100; p=25; m=25; r=5; b=0.4; seed=1984+m+nrow+p+n+r+b*10; ntst=n
err.result = simu(nrep,n,nvld,ntst,nrow,p,m,r,rho,sigma,b,seed)
printtable(err.result)


#rhat
#mean(err.result[,1,length(penal.const)+1,4])
#sd(err.result[,1,length(penal.const)+1,4])

#Summary stat
#print(apply(err.result[,,length(penal.const)+1,1:3],c(2,3),mean))
#print(apply(err.result[,,length(penal.const)+1,1:3],c(2,3),sd))