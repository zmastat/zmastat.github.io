function [PC, k, th, sigma2_hat] = ASPCAalp(data, L, basis, alpha, dothres, eigopt)

% Sparse Principal Component Analysis with Simple Selection Rule
%
% Function Prototype:
%   function [PC, k, th, sigma2_hat] = ASPCAalp(data, L, basis, alpha, dothres, eigopt)
%
% INPUT
%   data        an n*p data matrix with n observations in p-dim space
%   L           coarsest level in the wavelet transformation
%   basis       wavelet basis to be used, choose one from 'Haar', 'Beylkin', 
%               'Coiflet', 'Daubechies', 'Symmlet', 'Vaidyanathan','Battle'
%   alpha       adjustable constant in the simple selection rule
%   dothres     type of thresholding to perfrom on estimated eigenvector, choose
%               one from: 'none', 'hard', 'soft'
%   eigopt      option for MATLAB routine used to compute the eigenvectors
%               with default = 0: 0 = eig(), 1 = eigs()
%     
% OUTPUT
%   PC            1*p matrix, the estimated 1st principal components
%   k             size of the selected subsets
%   th            choice of threshold
%   sigma2_hat    estimate of the noise level  
%
% Reference: Johnstone and Lu (2009) JASA paper.


if nargin == 5
    eigopt = 0;
end
[n,p] = size(data);

% Step 1: Select Basis
% wavelet transformation: "wc" contains the coefficients
qmf = MakeONFilter(basis, 8);
wc = zeros(n,p);
for i = 1:n
	wc(i, :) = FWT_PO(data(i, :), L, qmf);
end;

% Step 2: Subset
% choose the k Wavelet coefficients with the largest variances.
wc_var = var(wc);
alpha_n = alpha * sqrt( log(n)./n);
[val, idx] = sort(-wc_var); 
sigma2_hat = median(wc_var);
k = sum( wc_var > sigma2_hat * (1 + alpha_n));
I = idx(1:k);

% Step 3: Reduced PCA [we consider only the first component here]
if eigopt == 1
    opts.disp = 0; % mute diagnostic display of eigs()
    [wcPC,D] = eigs(cov(wc(:,I)),1,opts);
else
    [wcPC,D] = eig(cov(wc(:,I)));
    wcPC = wcPC(:,k);
end

% Step 4: Thresholding
rhonorm2_hat = max(sum(wc_var) - p * sigma2_hat, sqrt(p/n) * sigma2_hat);
tau_hat = sqrt(sigma2_hat * (rhonorm2_hat + sigma2_hat)) / (sqrt(n) * rhonorm2_hat);
th = tau_hat * sqrt(2 * log(k));
if strcmp(dothres, 'hard')
    wcPC = hard_thresholding(wcPC, th);
elseif strcmp(dothres, 'soft')
    wcPC = soft_thresholding(wcPC, th);
elseif strcmp(dothres, 'none')
    th = 0;
else
    disp('Could not understand your choice of *dothres*! No thresholding performed!');
    th = 0;
end

k = length(find(wcPC)); % check the number of non-zero elements in the thresholded estimator

% Step 5: Reconstruction
wcPC_aug = zeros(p, 1);
wcPC_aug(I,:) = wcPC;
PC = IWT_PO(wcPC_aug, L, qmf);

% last modified: ZM, 2009-02-19
