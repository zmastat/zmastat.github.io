function [PC, k, th, sigma2_hat] = ASPCA(data, L, basis, perc, dothres, eigopt)

% ASPCA -- Adpative Sparse Principal Component Analysis
%
% Function Prototype:
%   function [PC, k, th, sigma2_hat] = ASPCA(data, L, basis, perc, dothres, eig.opt)
%
% INPUT
%   data        an n*p data matrix with n observations in p-dim space
%   L           coarsest level in the wavelet transformation
%   basis       wavelet basis to be used, choose one from 'Haar', 'Beylkin', 
%               'Coiflet', 'Daubechies', 'Symmlet', 'Vaidyanathan','Battle'
%   perc        fraction of total excesses to be captured by the selected 
%               subset
%   dothres     type of thresholding to perfrom on estimated eigenvector, 
%               choose one from: 'none', 'hard', 'soft'
%   eigopt      option for MATLAB routine used to compute the eigenvectors
%               with default = 0: 0 = eig(), 1 = eigs()
%     
% OUTPUT
%   PC            1*p matrix, the estimated 1st principal component
%   k             size of the selected subsets
%   th            choice of threshold
%   sigma2_hat    estimate of the noise level  
%
% Reference: Johnstone and Lu (2009) JASA paper.

if nargin == 5
    eigopt = 0;
end
[n,p] = size(data);

% Step 1: Select Basis
% wavelet transformation: "wc" contains the coefficients
qmf = MakeONFilter(basis, 8);
wc = zeros(n,p);
for i = 1:n
	wc(i, :) = FWT_PO(data(i, :), L, qmf);
end;

% Step 2: Subset
% choose the k Wavelet coefficients with the largest variances.
wc_var = var(wc);
[val, idx] = sort(-wc_var);
wc_var_o = -val;
sigma2_hat = median(wc_var);
ss = sigma2_hat / (n-1);
beta = 0.5;
pb = round(beta*p); % use at most the first half features
qtilev = (p - (1:pb))./p;
exs = max(0, wc_var_o(1:pb) - ss*chi2inv(qtilev, n-1));
exs_tot = sum(exs);
exs_acc = 0;
k=pb;
for i = 1:pb % data based choice of k
    exs_acc = exs_acc + exs(i);
    if (exs_acc / exs_tot > perc)
        k = i;
        break;
    end;
end;
I = idx(1:k);

% Step 3: Reduced PCA [we consider only the first component here]
if eigopt == 1
    opts.disp = 0; % mute diagnostic display of eigs()
    [wcPC,D] = eigs(cov(wc(:,I)),1,opts);
else
    [wcPC,D] = eig(cov(wc(:,I)));
    wcPC = wcPC(:,k);
end

% Step 4: Thresholding
rhonorm2_hat = max(sum(wc_var_o) - p * sigma2_hat, sqrt(p/n) * sigma2_hat);
tau_hat = sqrt(sigma2_hat * (rhonorm2_hat + sigma2_hat)) / (sqrt(n) * rhonorm2_hat);
th = tau_hat * sqrt(2 * log(k)); % computing the threshold value
if strcmp(dothres, 'hard')
    wcPC = hard_thresholding(wcPC, th);
elseif strcmp(dothres, 'soft')
    wcPC = soft_thresholding(wcPC, th);
elseif strcmp(dothres, 'none')
    th = 0;
else
    disp('Could not understand your choice of *dothres*! No thresholding performed!');
    th = 0;
end

k = length(find(wcPC)); % check the number of non-zero elements in the thresholded estimator

% Step 5: Reconstruction
wcPC_aug = zeros(p, 1);
wcPC_aug(I,:) = wcPC;
PC = IWT_PO(wcPC_aug, L, qmf);

% last modified: ZM, 2009-02-19
