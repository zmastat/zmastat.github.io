% Smoothed Principal Component Analysis
% Procedure described in Ramsay and Silverman (2005, Sec.9.4)
% Cubic B-spline basis is used
%
% Function Prototype:
%   function [PC] = SmoothPCA(data, tau, lambda)
%
% INPUT
%   data: n*p data matrix
%   tau: points at which the function is to be evaluated
%   lambda: smoothing parameter
%
% OUTPUT
%   PC: p*min(n,p) matrix, columns are eigenvectors of increasing eigenvalues


function [PC] = SmoothPCA(data, tau, lambda)

[n,p] = size(data);
k = 4;
knots = augknt(linspace(0,1,n-2),k);
colmat = spcol(knots,k,brk2knt(tau,3));
Phi = colmat(1:3:end,:)';
J = Phi * Phi';
D2Phi = colmat(3:3:end,:)';
K = D2Phi * D2Phi';
L = (chol(J + lambda * K))'; S = L^(-1);
C = (data * Phi' * J^(-1))';
D = S * J * C;
[U,EV] = eig(cov(D'));
Y = S' * U(:,n:-1:1);
for i = 1:n
    Y(:,i) = Y(:,i) / sqrt(Y(:,i)' * J * Y(:,i));
end;
PC = Phi' * Y;

% last modified: ZM, 2008-11-16
