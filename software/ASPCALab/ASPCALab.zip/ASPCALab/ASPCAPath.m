disp('Welcome to ASPCALab v 0.2!');
disp(' ');
disp('Setting up paths...');

WAVELABPATH = fullfile(matlabroot,'toolbox','Wavelab850')

% adapted from WavePath.m in Wavelab850
while (exist(WAVELABPATH)~=7)
    WAVELABPATH = input(sprintf('Directory %s does not exist.\nEnter the correct path (type 0 to exit): ',WAVELABPATH),'s')
    if WAVELABPATH == '0'
        fprintf('\nErrors occurs and Wavelab paths have not been set up!\n')
        fprintf('\nPlease Identify the correct Wavelab directory!\n\n')
        clear all;
        return;
    end
    WAVELABPATH = fullfile(WAVELABPATH);
end

fprintf('\nWavelab directory identified.\n');
fprintf('\nIncluding required WaveLab paths:\n');
path(fullfile(WAVELABPATH, 'Orthogonal'), path);
path(fullfile(WAVELABPATH, 'Utilities'), path);
fprintf('Required Wavelab paths are set up.\n');

fprintf('\nIncluding required splines toolbox paths:\n');
if (exist(fullfile(matlabroot,'toolbox','splines'))~=7)
    disp('Warning: Standard splines toolbox not available! SmoothPCA.m will not run!');
end
path(fullfile(matlabroot,'toolbox','splines'), path);
fprintf('Required splines toolbox paths are set up.\n');

ASPCAPATH = cd
fprintf('\nIncluding ASPCALab paths:\n');
addpath(genpath(ASPCAPATH));

% path(fullfile(ASPCAPATH,'AdaptivePCA'), path);
% path(fullfile(ASPCAPATH,'Documentation'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09Discussion'), path);
% path(fullfile(ASPCAPATH,'Paper','JASA09Rejoinder'), path);
% path(fullfile(ASPCAPATH,'SmoothedPCA'), path);
% path(fullfile(ASPCAPATH,'Utilities'), path);

fprintf('ASPCALab paths are set up.\n');

MODSTARTUP = ' ';
while (MODSTARTUP ~= 'y' & MODSTARTUP ~= 'n')
    MODSTARTUP = input(sprintf('Do you want to add ASPCALab paths to your startup.m?\n[y for Yes/n for NO]\n'),'s');
    if isempty(MODSTARTUP)
        MODSTARTUP = 'y';
    end
end
if MODSTARTUP == 'y'
    disp('Modifying startup.m:');
    STARTUPPATH = userpath;
    STARTUPPATH = STARTUPPATH(1:end-1);
    fid = fopen(fullfile(STARTUPPATH, 'startup.m'),'a+');
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'AdaptivePCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'Documentation'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'Paper','JASA09'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'Paper','JASA09Discussion'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'Paper','JASA09Rejoinder'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'SmoothedPCA'));
    fprintf(fid, 'addpath %s;\n', fullfile(ASPCAPATH,'Utilities'));
    fclose(fid);
    disp('Modification to startup.m is completed.');
    fprintf('\nASPCALab v 0.2 is successfully installed!\n\n');
else
    fprintf('\nASPCALab v 0.2 is ready for use in the current MATLAB session!\n\n')
end

% last modified: ZM, 2009-02-25


