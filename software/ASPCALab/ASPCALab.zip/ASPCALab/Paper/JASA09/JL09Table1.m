% Table 1 of Johnstone and Lu (2009):
% Simulation study: accuracy comparison of standard, smoothed, and adaptive
% sparse PCA. Please call JL08Figure3 prior to this function.

disp('This function reproduces Table 1 of Johnstone & Lu (2009).');
R = input('Have you called JL09Figure3? [Yes/No]\n', 's');
if strcmp(R,'') || strcmp(R,'Yes') || strcmp(R,'yes') || strcmp(R,'y') || strcmp(R,'Y') || strcmp(R,'YES')
    ase_peak = csvread(fullfile(cd, 'ase_peak.dat'));
    ase_step = csvread(fullfile(cd, 'ase_step.dat'));
    time_peak = csvread(fullfile(cd, 'time_peak.dat'));
    time_step = csvread(fullfile(cd, 'time_step.dat'));
    table1 = zeros(4,5);
    table1(1,:) = mean(ase_peak);
    table1(2,:) = mean(time_peak);
    table1(3,:) = mean(ase_step);
    table1(4,:) = mean(time_step);
    disp('  ');
    disp('          =========Table 1 in Johnstone & Lu (2008)=========          ');
    disp('              Standard  Smoothed    Smoothed   SparsePCA  SparsePCA');
    disp('                 PCA    PCA:10E-12  PCA:10E-6  No Thresh  Thresh@.01');
    fprintf(' ASE(3-peak)');
    for i = 1:5 
        fprintf('  ');
        fprintf(num2str(table1(1,i),'%10.2e'));
    end
    fprintf('\n');
    fprintf('Time(3-peak)');
    for i = 1:5 
        fprintf('  ');
        fprintf(num2str(table1(2,i),'%10.2e'));
    end
    fprintf('\n');
    fprintf('   ASE(step)');
    for i = 1:5 
        fprintf('  ');
        fprintf(num2str(table1(3,i),'%10.2e'));
    end
    fprintf('\n');
    fprintf('  Time(step)');
    for i = 1:5 
        fprintf('  ');
        fprintf(num2str(table1(4,i),'%10.2e'));
    end
    fprintf('\n\n');
else
    disp('Table 1 could not be reproduced! Call JL09Figure3 first!');
end
