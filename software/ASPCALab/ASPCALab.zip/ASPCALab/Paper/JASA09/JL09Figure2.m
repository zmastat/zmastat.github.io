% Figure 2 of Johnstone and Lu (2009):
% step function and PCs from standard, smoothed, and ASPCA.

fprintf('This function reproduces Fig.2 of Johnstone & Lu (2009).\n');
fprintf('Processing...\n\n');

% set seed
state = 100;
randn('state', state);

% set parameter
n = 1024;
p = 2048;
sigma = 1;
len = 25;
% ASPCA parameters
perc = 0.995;
basis = 'Haar';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%  Construct Step Function  %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rhoStep = zeros(1,p);
cut1 = round(0.07*p);
cut2 = round(0.1*p);
cut3 = round(0.17*p);
cut4 = round(0.35*p);
cut5 = round(0.39*p);
cut6 = round(0.45*p);
cut7 = round(0.72*p);
cut8 = round(0.82*p);
cut9 = round(0.85*p);
cut10 = round(0.89*p);

rhoStep(cut1:cut2)=1;
rhoStep((cut2+1):cut3)=-0.6;
rhoStep((cut3+1):cut4)=0.5;
rhoStep((cut4+1):cut5)=-0.8;
rhoStep((cut5+1):cut6)=0.7;
rhoStep((cut6+1):cut7)=-0.4;
rhoStep((cut7+1):cut8)=0.9;
rhoStep((cut8+1):cut9)=0.2;
rhoStep((cut9+1):cut10)=0.7;

rhoStep = len * rhoStep' / norm(rhoStep);

% Generate data matrix (1024*2048) Xstep

ps = linspace(0,1,p);
mu = 0 * (1:p);
Xstep = GenData(n, mu, rhoStep', sigma);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%  Different PCAs on Step Function  %%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% for determining the sign of the eigenvector
idx = find(rhoStep == max(rhoStep)); idx = idx(1);

%%%%%%%%%%%%%%%%
% Standard PCA %
%%%%%%%%%%%%%%%%
[V,D] = eig(cov(Xstep));
V = V(:,p); V = sign(V(idx,1)) * V;
rhoStepHat_st = len * V / norm(V');

dif_st = rhoStep - rhoStepHat_st;
fprintf('The MSE of standard PCA is:\n');
disp(num2str(norm(dif_st) / p));

%%%%%%%%%%%%%%%%
% Smoothed PCA %
%%%%%%%%%%%%%%%%

% lambda = 10E-12
SmPC = SmoothPCA(Xstep, ps, 10^(-12));
SmPC = SmPC(:,1); SmPC = sign(SmPC(idx,1)) * SmPC;
rhoStepHat_12 = len * SmPC/norm(SmPC');

dif_12 = rhoStep - rhoStepHat_12;
fprintf('The MSE of smoothed PCA with smoothness penalty 10E-12 is:\n');
disp(num2str(norm(dif_12) / p));

% lambda = 10E-8
SmPC = SmoothPCA(Xstep, ps, 10^(-8));
SmPC = SmPC(:,1); SmPC = sign(SmPC(idx,1)) * SmPC;
rhoStepHat_8 = len * SmPC/norm(SmPC');

dif_8 = rhoStep - rhoStepHat_8;
fprintf('The MSE of smoothed PCA with smoothness penalty 10E-8 is:\n');
disp(num2str(norm(dif_8) / p));

% lambda = 10E-6
SmPC = SmoothPCA(Xstep, ps, 10^(-6));
SmPC = SmPC(:,1); SmPC = sign(SmPC(idx,1)) * SmPC;
rhoStepHat_6 = len * SmPC/norm(SmPC');

dif_6 = rhoStep - rhoStepHat_6;
fprintf('The MSE of smoothed PCA with smoothness penalty 10E-6 is:\n');
disp(num2str(norm(dif_6) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adaptive Sparse PCA W/O thresholding %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[AsPC, card_sub, th] = ASPCA(Xstep, 8, basis, perc, 'none');
AsPC = sign(AsPC(idx,1)) * AsPC;
rhoStepHat_nt = len * AsPC/norm(AsPC');

dif_nt = rhoStep - rhoStepHat_nt;
fprintf('The MSE of Adaptive SPCA without thresholding is:\n');
disp(num2str(norm(dif_nt) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adaptive Sparse PCA with hard thresholding, th = 0.01 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[AsPC, card_sub1, th] = ASPCA(Xstep, 8, basis, perc, 'hard');
AsPC = sign(AsPC(idx,1)) * AsPC;
rhoStepHat_t = len * AsPC/norm(AsPC');

dif_t = rhoStep - rhoStepHat_t;
fprintf('The MSE of Adaptive SPCA with hard thresholding at 0.01 is:\n');
disp(num2str(norm(dif_t) / p));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%            Plot 6 graphs           %%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clf;
subplot(2,3,1);
plot(rhoStep, 'black');
box on;
axis([0 2048 -1 1.4]);
title('a) True PC, p = 2048, n = 1024, ||\rho|| = 25.');

subplot(2,3,2)
plot(1:2048, Xstep(1,:))
axis([0 2048 -4 4]);
title('b) A sample path from model (2)')

subplot(2,3,3);
hold on;
box on;
l2 = plot(rhoStepHat_st,'blue');
axis([0 2048 -1 1.4]);
title('c) Standard PCA');

subplot(2,3,4);
axis([0 2048 -1 1.4]);
hold on;
box on;
l2 = plot(rhoStepHat_12,'r --');
l3 = plot(rhoStepHat_8, 'b ');
l4 = plot(rhoStepHat_6,'m -.');
% legend([l2 l3 l4], '\lambda=10^{-12}', '\lambda=10^{-8}', '\lambda=10^{-6}');
title('d) Smoothed PCA, r:10^{-12}, b:10^{-8}, m:10^{-6}.');

subplot(2,3,5);
hold on;
box on;
axis([0 2048 -1 1.4]);
l2 = plot(rhoStepHat_nt,'blue');
tit = strcat('e) ASPCA: w=', num2str(perc), ', k=', int2str(card_sub), '. ');
title(strcat(tit, ' No thres.'));

subplot(2,3,6);
hold on;
box on;
axis([0 2048 -1 1.4]);
l2 = plot(rhoStepHat_t,'blue');
tit = strcat('f) ASPCA: w=', num2str(perc), ', k=', int2str(card_sub1), '. ');
title(strcat(tit, ' Thres=', num2str(th,3), '.'));
