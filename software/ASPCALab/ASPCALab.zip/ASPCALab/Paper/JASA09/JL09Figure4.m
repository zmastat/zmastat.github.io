% Figure 4 of Johnstone and Lu (2009):
% Real ECG data baseline wander.

baseCurve = load('BaselineWander.curve');

a = [80, 435, 789, 1164, 1547, 1900];

plot(baseCurve, 'black');
hold on;

plot(a,baseCurve(a),'-- blue')
plot(80, baseCurve(80), '* red');
plot(435, baseCurve(435), '* red');
plot(789, baseCurve(789), '* red');
plot(1164, baseCurve(1164), '* red');
plot(1547, baseCurve(1547), '* red');
plot(1900, baseCurve(1900), '* red');


